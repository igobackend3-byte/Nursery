import { useState } from 'react';

function Login() {
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);
  const [notice, setNotice] = useState('');

  function handleSubmit(e) {
    e.preventDefault();
    setNotice('This is a demo store — accounts and orders are not connected to a backend yet.');
  }

  return (
    <div className="login-page">
      <form className="login-card" onSubmit={handleSubmit}>
        <p className="eyebrow">WELCOME BACK</p>
        <h1>Log In</h1>
        <p className="login-sub">Sign in to view orders, addresses and your account.</p>

        <label className="field-label" htmlFor="login-id">Phone Number or Email</label>
        <input id="login-id" type="text" placeholder="9876543210 or jane@example.com" />

        <label className="field-label" htmlFor="login-pw">Password</label>
        <div className="password-field">
          <input id="login-pw" type={showPassword ? 'text' : 'password'} placeholder="Enter your password" />
          <button type="button" onClick={() => setShowPassword((s) => !s)}>
            {showPassword ? 'HIDE' : 'SHOW'}
          </button>
        </div>

        <div className="login-row">
          <label className="remember-me">
            <input type="checkbox" checked={rememberMe} onChange={() => setRememberMe((r) => !r)} />
            Remember Me
          </label>
          <a href="#forgot">Forgot Password?</a>
        </div>

        <button type="submit" className="btn-login">Login</button>
        {notice && <p className="login-notice">{notice}</p>}
        <p className="login-signup">Don&apos;t have an account? <a href="#signup">Sign Up</a></p>
      </form>
    </div>
  );
}

export default Login;
