import { useMemo, useState } from 'react';
import { useParams } from 'react-router-dom';
import ProductCard from '../components/ProductCard';
import { CATEGORIES, getGiftProducts, getProductsByCategory } from '../data/products';

const PLANT_FACETS = [
  { key: 'size', title: 'Plant Size' },
  { key: 'light', title: 'Light Requirement' },
  { key: 'location', title: 'Ideal Location' },
  { key: 'maintenance', title: 'Maintenance' },
  { key: 'water', title: 'Water Schedule' },
];

const GIFT_FACETS = [
  { key: 'giftType', title: 'Gift Type' },
  { key: 'productType', title: 'Product Type' },
];

function FacetGroup({ title, options, selected, onToggle }) {
  return (
    <div className="facet-group">
      <h4>{title}</h4>
      <ul>
        {options.map(({ value, count }) => (
          <li key={value}>
            <label>
              <input
                type="checkbox"
                checked={selected.includes(value)}
                onChange={() => onToggle(value)}
              />
              <span>{value}</span>
              <em>{count}</em>
            </label>
          </li>
        ))}
      </ul>
    </div>
  );
}

function CategoryPage({ slugOverride }) {
  const { slug: slugParam } = useParams();
  const slug = slugOverride ?? slugParam;
  const isGiftPage = slug === 'gifting' || slug === 'corporate-gifts';

  const baseProducts = useMemo(() => {
    if (slug === 'gifting') return getGiftProducts();
    if (slug === 'corporate-gifts') return getGiftProducts();
    return getProductsByCategory(slug);
  }, [slug]);

  const meta = CATEGORIES.find((c) => c.slug === slug);
  const heading = isGiftPage
    ? slug === 'gifting'
      ? 'Gifting'
      : 'Corporate Gifts'
    : meta?.label ?? 'All Products';
  const tagline = isGiftPage
    ? 'Thoughtful, ready-to-gift plants and planters for every occasion.'
    : meta?.tagline ?? '';

  const facetDefs = isGiftPage ? GIFT_FACETS : PLANT_FACETS;
  const [selectedFacets, setSelectedFacets] = useState({});
  const prices = baseProducts.map((p) => p.price);
  const minPrice = prices.length ? Math.min(...prices) : 0;
  const maxPrice = prices.length ? Math.max(...prices) : 0;
  const [priceMax, setPriceMax] = useState(maxPrice);

  const effectivePriceMax = priceMax || maxPrice;

  function toggleFacet(key, value) {
    setSelectedFacets((prev) => {
      const current = prev[key] ?? [];
      const next = current.includes(value)
        ? current.filter((v) => v !== value)
        : [...current, value];
      return { ...prev, [key]: next };
    });
  }

  const filtered = baseProducts.filter((p) => {
    if (isGiftPage && p.price > effectivePriceMax) return false;
    return facetDefs.every(({ key }) => {
      const selected = selectedFacets[key];
      if (!selected || selected.length === 0) return true;
      return selected.includes(p[key]);
    });
  });

  return (
    <div className="category-page">
      <div className="category-hero">
        <p className="eyebrow">{isGiftPage ? 'GIFTING' : 'CATEGORY'}</p>
        <h1>{heading}</h1>
        <p className="category-tagline">{tagline}</p>
      </div>

      <div className="category-layout">
        <aside className="filter-sidebar">
          <p className="filter-count">{filtered.length} products found</p>

          {isGiftPage && (
            <div className="facet-group price-facet">
              <h4>Price</h4>
              <div className="price-inputs">
                <span>₹{minPrice}</span>
                <span>—</span>
                <span>₹{effectivePriceMax}</span>
              </div>
              <input
                type="range"
                min={minPrice}
                max={maxPrice}
                value={effectivePriceMax}
                onChange={(e) => setPriceMax(Number(e.target.value))}
              />
            </div>
          )}

          {facetDefs.map(({ key, title }) => {
            const counts = new Map();
            baseProducts.forEach((p) => {
              const val = p[key];
              if (!val) return;
              counts.set(val, (counts.get(val) ?? 0) + 1);
            });
            const options = Array.from(counts.entries()).map(([value, count]) => ({ value, count }));
            if (options.length === 0) return null;
            return (
              <FacetGroup
                key={key}
                title={title}
                options={options}
                selected={selectedFacets[key] ?? []}
                onToggle={(value) => toggleFacet(key, value)}
              />
            );
          })}
        </aside>

        <div className="product-grid">
          {filtered.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
          {filtered.length === 0 && <p className="empty-state">No products match your filters.</p>}
        </div>
      </div>
    </div>
  );
}

export default CategoryPage;
