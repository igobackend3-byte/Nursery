// Mock product catalogue for IGO Nursery

export const CATEGORIES = [
  { slug: 'indoor-plants', label: 'Indoor Plants', tagline: 'Easy greenery for every room', image: 'https://images.unsplash.com/photo-1416879595882-3373a0480b5b?q=80&w=800&auto=format&fit=crop' },
  { slug: 'outdoor-plants', label: 'Outdoor Plants', tagline: 'Colour and life for open spaces', image: 'https://images.unsplash.com/photo-1523348837708-15d4a09cfac2?q=80&w=800&auto=format&fit=crop' },
  { slug: 'seeds', label: 'Seeds', tagline: 'Start from scratch and watch it grow', image: 'https://images.unsplash.com/photo-1462530260150-162092dbf011?q=80&w=800&auto=format&fit=crop' },
  { slug: 'pots-planters', label: 'Pots & Planters', tagline: 'Give every plant a home it deserves', image: 'https://images.unsplash.com/photo-1485955900006-10f4d324d411?q=80&w=800&auto=format&fit=crop' },
  { slug: 'gardening-tools', label: 'Gardening Tools', tagline: 'Everything you need to get your hands dirty', image: 'https://images.unsplash.com/photo-1502394202744-021cfbb17454?q=80&w=800&auto=format&fit=crop' },
  { slug: 'garden-decor', label: 'Garden Décor', tagline: 'Finishing touches for a beautiful garden', image: 'https://images.unsplash.com/photo-1487530811176-3780de880c2d?q=80&w=800&auto=format&fit=crop' },
  { slug: 'bonsai', label: 'Bonsai', tagline: 'Patience, shaped into art', image: 'https://images.unsplash.com/photo-1611048267451-e6ed903d4a38?q=80&w=800&auto=format&fit=crop' },
];

const IMG = {
  indoor: [
    'https://images.unsplash.com/photo-1545241047-6083a3684587?q=80&w=600&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1463154545680-d59320fd685d?q=80&w=600&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1512428813834-c702c7702b78?q=80&w=600&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1520412099551-62b6bafeb5bb?q=80&w=600&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1463320726281-696a485928c7?q=80&w=600&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1493957988430-a5f2e15f39a3?q=80&w=600&auto=format&fit=crop',
  ],
  outdoor: [
    'https://images.unsplash.com/photo-1490750967868-88aa4486c946?q=80&w=600&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1508022713622-df2d8fb7b4cd?q=80&w=600&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1425913397330-cf8af2ff40a1?q=80&w=600&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1463320726281-696a485928c7?q=80&w=600&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1591958911259-bee2173bdccc?q=80&w=600&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1533038590840-1cde6e668a91?q=80&w=600&auto=format&fit=crop',
  ],
  seeds: [
    'https://images.unsplash.com/photo-1591857177580-dc82b9ac4e1e?q=80&w=600&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1596547609652-9cf5d8d76921?q=80&w=600&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1493957988430-a5f2e15f39a3?q=80&w=600&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1509587584298-0f3b3a3a1797?q=80&w=600&auto=format&fit=crop',
  ],
  pots: [
    'https://images.unsplash.com/photo-1485955900006-10f4d324d411?q=80&w=600&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1459156212016-c812468e2115?q=80&w=600&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1518241353330-0f7941c2d9b5?q=80&w=600&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1560717845-968823efbee1?q=80&w=600&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1502394202744-021cfbb17454?q=80&w=600&auto=format&fit=crop',
  ],
  tools: [
    'https://images.unsplash.com/photo-1502394202744-021cfbb17454?q=80&w=600&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1461354464878-ad92f492a5a0?q=80&w=600&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1591857177580-dc82b9ac4e1e?q=80&w=600&auto=format&fit=crop',
  ],
  decor: [
    'https://images.unsplash.com/photo-1487530811176-3780de880c2d?q=80&w=600&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1477414348463-c0eb7f1359b6?q=80&w=600&auto=format&fit=crop',
  ],
  bonsai: [
    'https://images.unsplash.com/photo-1611048267451-e6ed903d4a38?q=80&w=600&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1576678927484-cc907957088c?q=80&w=600&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1519336056116-bc0f1771dec8?q=80&w=600&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1521133573892-e44906baee46?q=80&w=600&auto=format&fit=crop',
  ],
};

let counter = 1;
function nextId() {
  return `p-${counter++}`;
}

function makeProduct({
  name, category, categoryLabel, price, originalPrice, image,
  size = 'Medium (20-60cm)', light = 'Full sun to partial shade',
  location = 'Garden bed, terrace or balcony', maintenance = 'Medium Maintenance',
  water = 'Regular watering, more in summer', rating, reviews,
  gift = false, giftType, productType,
}) {
  return {
    id: nextId(),
    name,
    category,
    categoryLabel,
    price,
    originalPrice,
    discount: originalPrice - price,
    rating: rating ?? +(4 + Math.random()).toFixed(1),
    reviews: reviews ?? Math.floor(Math.random() * 130) + 8,
    image,
    size, light, location, maintenance, water,
    gift, giftType, productType: productType ?? categoryLabel,
  };
}

export const PRODUCTS = [
  // Indoor Plants
  makeProduct({ name: 'Money Plant / Golden Pothos', category: 'indoor-plants', categoryLabel: 'Indoor Plants', price: 199, originalPrice: 279, image: IMG.indoor[0], location: 'Indoors, tabletop or hanging', maintenance: 'Low Maintenance', water: 'Water when topsoil dries' }),
  makeProduct({ name: 'Chinese Evergreen Aglaonema', category: 'indoor-plants', categoryLabel: 'Indoor Plants', price: 349, originalPrice: 429, image: IMG.indoor[1], location: 'Indoors, low light corner', maintenance: 'Low Maintenance' }),
  makeProduct({ name: 'Corn Plant Dracaena', category: 'indoor-plants', categoryLabel: 'Indoor Plants', price: 429, originalPrice: 529, image: IMG.indoor[2], size: 'Large (Above 60cm)' }),
  makeProduct({ name: 'Boston Fern Nephrolepis', category: 'indoor-plants', categoryLabel: 'Indoor Plants', price: 249, originalPrice: 329, image: IMG.indoor[3], maintenance: 'High Maintenance', water: 'Keep soil consistently moist' }),
  makeProduct({ name: 'Snake Plant Sansevieria', category: 'indoor-plants', categoryLabel: 'Indoor Plants', price: 299, originalPrice: 379, image: IMG.indoor[4], maintenance: 'Low Maintenance', water: 'Water sparingly' }),
  makeProduct({ name: 'ZZ Plant Zamioculcas', category: 'indoor-plants', categoryLabel: 'Indoor Plants', price: 379, originalPrice: 459, image: IMG.indoor[5], maintenance: 'Low Maintenance' }),
  makeProduct({ name: 'Peace Lily Spathiphyllum', category: 'indoor-plants', categoryLabel: 'Indoor Plants', price: 329, originalPrice: 409, image: IMG.indoor[0] }),
  makeProduct({ name: 'Areca Palm', category: 'indoor-plants', categoryLabel: 'Indoor Plants', price: 549, originalPrice: 699, image: IMG.indoor[2], size: 'Large (Above 60cm)' }),

  // Outdoor Plants
  makeProduct({ name: 'Hibiscus', category: 'outdoor-plants', categoryLabel: 'Outdoor Plants', price: 309, originalPrice: 379, image: IMG.outdoor[0], rating: 5, reviews: 120 }),
  makeProduct({ name: 'Ixora / Jungle Flame', category: 'outdoor-plants', categoryLabel: 'Outdoor Plants', price: 349, originalPrice: 429, image: IMG.outdoor[1], rating: 4.5, reviews: 127 }),
  makeProduct({ name: 'Oleander', category: 'outdoor-plants', categoryLabel: 'Outdoor Plants', price: 389, originalPrice: 469, image: IMG.outdoor[2], rating: 4.9, reviews: 134 }),
  makeProduct({ name: 'Crepe Jasmine Nandiar Vattai', category: 'outdoor-plants', categoryLabel: 'Outdoor Plants', price: 419, originalPrice: 509, image: IMG.outdoor[3], rating: 4.4, reviews: 141 }),
  makeProduct({ name: 'Bougainvillea', category: 'outdoor-plants', categoryLabel: 'Outdoor Plants', price: 259, originalPrice: 319, image: IMG.outdoor[4], rating: 4.8, reviews: 8 }),
  makeProduct({ name: 'Peregrina Jatropha', category: 'outdoor-plants', categoryLabel: 'Outdoor Plants', price: 299, originalPrice: 359, image: IMG.outdoor[0], rating: 4.3, reviews: 15 }),
  makeProduct({ name: 'Lantana', category: 'outdoor-plants', categoryLabel: 'Outdoor Plants', price: 329, originalPrice: 399, image: IMG.outdoor[1], rating: 4.7, reviews: 22 }),
  makeProduct({ name: 'Gold Mound Duranta Golden', category: 'outdoor-plants', categoryLabel: 'Outdoor Plants', price: 369, originalPrice: 449, image: IMG.outdoor[2], rating: 4.2, reviews: 29 }),
  makeProduct({ name: 'Cardinal Creeper Ipomoea', category: 'outdoor-plants', categoryLabel: 'Outdoor Plants', price: 439, originalPrice: 539, image: IMG.outdoor[3], rating: 4.7, reviews: 57 }),
  makeProduct({ name: 'Coral Vine', category: 'outdoor-plants', categoryLabel: 'Outdoor Plants', price: 279, originalPrice: 339, image: IMG.outdoor[4], rating: 4.2, reviews: 64 }),
  makeProduct({ name: 'Curtain Creeper', category: 'outdoor-plants', categoryLabel: 'Outdoor Plants', price: 319, originalPrice: 389, image: IMG.outdoor[5], rating: 4.6, reviews: 71 }),
  makeProduct({ name: 'Golden Bamboo Mani Moongil', category: 'outdoor-plants', categoryLabel: 'Outdoor Plants', price: 919, originalPrice: 1119, image: IMG.outdoor[0], size: 'Large (Above 60cm)', rating: 5, reviews: 78 }),

  // Seeds
  makeProduct({ name: 'Marigold Seeds', category: 'seeds', categoryLabel: 'Seeds', price: 49, originalPrice: 79, image: IMG.seeds[0], size: 'Small (Under 20cm)', location: 'Garden bed or grow bag', maintenance: 'Low Maintenance' }),
  makeProduct({ name: 'California Poppy Seeds', category: 'seeds', categoryLabel: 'Seeds', price: 59, originalPrice: 89, image: IMG.seeds[1], size: 'Small (Under 20cm)' }),
  makeProduct({ name: 'Lavender Seeds', category: 'seeds', categoryLabel: 'Seeds', price: 69, originalPrice: 99, image: IMG.seeds[2], size: 'Small (Under 20cm)' }),
  makeProduct({ name: 'Loofah Ridge Gourd Seeds', category: 'seeds', categoryLabel: 'Seeds', price: 39, originalPrice: 59, image: IMG.seeds[3], size: 'Small (Under 20cm)' }),

  // Pots & Planters
  makeProduct({ name: 'Plain Round Terracotta Pot', category: 'pots-planters', categoryLabel: 'Pots & Planters', price: 269, originalPrice: 319, image: IMG.pots[0], productType: 'Pots & Planters' }),
  makeProduct({ name: 'Rimmed Terracotta Pot', category: 'pots-planters', categoryLabel: 'Pots & Planters', price: 309, originalPrice: 369, image: IMG.pots[1], productType: 'Pots & Planters' }),
  makeProduct({ name: 'Ridged / Grooved Terracotta Pot', category: 'pots-planters', categoryLabel: 'Pots & Planters', price: 349, originalPrice: 419, image: IMG.pots[2], productType: 'Pots & Planters' }),
  makeProduct({ name: 'Glazed-Rim Terracotta Pot', category: 'pots-planters', categoryLabel: 'Pots & Planters', price: 389, originalPrice: 469, image: IMG.pots[3], productType: 'Pots & Planters' }),
  makeProduct({ name: 'Painted Terracotta Pot', category: 'pots-planters', categoryLabel: 'Pots & Planters', price: 419, originalPrice: 499, image: IMG.pots[4], gift: true, giftType: 'Branded Planter Sets', productType: 'Pots & Planters' }),
  makeProduct({ name: 'Chettinad-Style Terracotta Pot', category: 'pots-planters', categoryLabel: 'Pots & Planters', price: 459, originalPrice: 549, image: IMG.pots[0], gift: true, giftType: 'Corporate Desk Plants', productType: 'Pots & Planters' }),
  makeProduct({ name: 'Terracotta Long Tom Pot', category: 'pots-planters', categoryLabel: 'Pots & Planters', price: 499, originalPrice: 599, image: IMG.pots[1], productType: 'Pots & Planters' }),
  makeProduct({ name: 'Terracotta Bonsai Pot (Shallow)', category: 'pots-planters', categoryLabel: 'Pots & Planters', price: 239, originalPrice: 289, image: IMG.pots[2], productType: 'Pots & Planters' }),

  // Gardening Tools
  makeProduct({ name: 'Coconut Husk Coco Peat Brick', category: 'gardening-tools', categoryLabel: 'Gardening Tools', price: 129, originalPrice: 169, image: IMG.tools[0], productType: 'Tools' }),
  makeProduct({ name: 'Coconut Potting Mix', category: 'gardening-tools', categoryLabel: 'Gardening Tools', price: 149, originalPrice: 199, image: IMG.tools[1], productType: 'Tools' }),
  makeProduct({ name: 'Vermicompost 5kg', category: 'gardening-tools', categoryLabel: 'Gardening Tools', price: 179, originalPrice: 229, image: IMG.tools[2], productType: 'Tools' }),
  makeProduct({ name: 'Hand Trowel & Weeder Set', category: 'gardening-tools', categoryLabel: 'Gardening Tools', price: 249, originalPrice: 319, image: IMG.tools[0], productType: 'Tools' }),

  // Garden Décor
  makeProduct({ name: 'Ceramic Wind Chime', category: 'garden-decor', categoryLabel: 'Garden Décor', price: 349, originalPrice: 449, image: IMG.decor[0], productType: 'Décor' }),
  makeProduct({ name: 'Rustic Garden Stake Set', category: 'garden-decor', categoryLabel: 'Garden Décor', price: 299, originalPrice: 379, image: IMG.decor[1], productType: 'Décor' }),

  // Bonsai
  makeProduct({ name: 'Chinese Banyan Ficus Bonsai', category: 'bonsai', categoryLabel: 'Bonsai', price: 1299, originalPrice: 1579, image: IMG.bonsai[0], gift: true, giftType: 'Corporate Bulk Gifting', productType: 'Bonsai', size: 'Small (Under 20cm)' }),
  makeProduct({ name: 'Banyan Bonsai', category: 'bonsai', categoryLabel: 'Bonsai', price: 1329, originalPrice: 1619, image: IMG.bonsai[1], gift: true, giftType: 'Corporate Bulk Gifting', productType: 'Bonsai', size: 'Small (Under 20cm)' }),
  makeProduct({ name: 'Bougainvillea Bonsai', category: 'bonsai', categoryLabel: 'Bonsai', price: 1369, originalPrice: 1669, image: IMG.bonsai[2], gift: true, giftType: 'Corporate Desk Plants', productType: 'Bonsai', size: 'Small (Under 20cm)' }),
  makeProduct({ name: 'Desert Rose Bonsai Adenium', category: 'bonsai', categoryLabel: 'Bonsai', price: 1409, originalPrice: 1719, image: IMG.bonsai[3], gift: true, giftType: 'Corporate Desk Plants', productType: 'Bonsai', size: 'Small (Under 20cm)' }),

  // Gift-tagged mini plants / orchids for gifting & corporate pages
  makeProduct({ name: 'Mini Succulent Trio', category: 'indoor-plants', categoryLabel: 'Indoor Plants', price: 349, originalPrice: 429, image: IMG.indoor[4], gift: true, giftType: 'Corporate Desk Plants', productType: 'Mini Plants', size: 'Small (Under 20cm)' }),
  makeProduct({ name: 'Cocooil Plant Care Gift Set', category: 'garden-decor', categoryLabel: 'Garden Décor', price: 499, originalPrice: 599, image: IMG.tools[1], gift: true, giftType: 'Branded Planter Sets', productType: 'Pots & Planters' }),
  makeProduct({ name: 'Phalaenopsis Orchid', category: 'indoor-plants', categoryLabel: 'Indoor Plants', price: 799, originalPrice: 949, image: IMG.bonsai[2], gift: true, giftType: 'Corporate Desk Plants', productType: 'Orchids', size: 'Small (Under 20cm)' }),
];

export function getProductsByCategory(slug) {
  return PRODUCTS.filter((p) => p.category === slug);
}

export function getGiftProducts() {
  return PRODUCTS.filter((p) => p.gift);
}

export function getProductById(id) {
  return PRODUCTS.find((p) => p.id === id);
}

export function getBestSellers(count = 8) {
  return [...PRODUCTS].sort((a, b) => b.rating - a.rating).slice(0, count);
}
