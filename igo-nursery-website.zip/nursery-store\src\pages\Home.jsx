import { useState } from 'react';
import { Link } from 'react-router-dom';
import ProductCard from '../components/ProductCard';
import OffersSection from '../components/OffersSection';
import { CATEGORIES, getBestSellers } from '../data/products';

const WHY_IGO = [
  { title: 'IoT-monitored nurseries', desc: 'Every polyhouse tracks temperature, humidity and soil health in real time.' },
  { title: 'Precision trials', desc: 'New varieties are tested for months before they ever reach your cart.' },
  { title: '99.2% health guarantee', desc: 'Plants leave the lab only when they clear our quality checks.' },
  { title: 'Expert plant-care guidance', desc: 'Free care notes and a support line for every plant you buy.' },
];

const JOURNAL = [
  { title: 'How to choose your first indoor plant', to: '/blog' },
  { title: 'A simple guide to potting mix', to: '/blog' },
  { title: '3 ways to make a balcony feel greener', to: '/blog' },
];

const REVIEWS = [
  { name: 'Ananya R.', rating: 5, text: 'The plants arrived so much healthier than I expected. Great packaging too.' },
  { name: 'Karthik S.', rating: 5, text: 'Ordered a bonsai as a gift — the recipient loved it. Will order again.' },
  { name: 'Priya M.', rating: 4, text: 'Good range of pots and the care guide that came with my order was genuinely useful.' },
];

const FAQS = [
  { q: 'How are plants packaged for delivery?', a: 'Every plant ships in a secure nursery pot with moisture-locking wrap and a care card, so it arrives ready to repot.' },
  { q: 'Do you offer a health guarantee?', a: 'Yes — if a plant arrives damaged or unhealthy, we replace it free within 7 days of delivery.' },
  { q: 'Can I get gardening help after I buy?', a: 'Every order includes access to our plant-care guidance line for as long as you own the plant.' },
  { q: 'Do you deliver pots and planters separately?', a: 'Yes, pots, seeds and tools can be ordered on their own or bundled with a plant.' },
];

function Hero() {
  return (
    <section className="hero-section">
      <div className="hero-content">
        <div className="tag">
          <div className="tag-dot"></div>
          MUTTUKADU LAB ONLINE
        </div>
        <h1 className="hero-title">
          NATURE<br />
          <span className="highlight-text">ENGINEERED.</span>
          <svg style={{ display: 'inline-block', marginLeft: '12px' }} width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="var(--color-primary-lime)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
            <path d="M12 22C12 22 20 18 20 12V5l-8-3-8 3v7C4 18 12 22 12 22z"></path>
          </svg>
        </h1>
        <p className="hero-description">
          IGO is not just a nursery. We are an AgriTech farm using IoT data
          and precision trials to grow the healthiest plant palette in India.
        </p>
        <div className="hero-buttons">
          <button type="button" className="btn btn-primary">
            START GARDEN ASSISTANT ⚡
          </button>
          <Link to="/category/indoor-plants" className="btn btn-secondary">
            SHOP PLANTS
          </Link>
        </div>
      </div>

      <div className="glass-card temp-card">
        <div className="card-icon">
          <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M14 14.76V3.5a2.5 2.5 0 0 0-5 0v11.26a4.5 4.5 0 1 0 5 0z"></path>
          </svg>
        </div>
        <div className="card-data">
          <h3>28.4°C</h3>
          <p>CORE LAB TEMP</p>
          <div className="sparkline"></div>
        </div>
      </div>

      <div className="glass-card health-card">
        <div className="card-icon">
          <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path>
            <polyline points="9 12 11 14 15 10"></polyline>
          </svg>
        </div>
        <div className="card-data">
          <h3>99.2%</h3>
          <p>HEALTH GUARANTEE</p>
        </div>
      </div>

      <div className="hero-circle-container">
        <div className="hero-image"></div>
      </div>
    </section>
  );
}

function ShopByCategory() {
  return (
    <section className="shop-by-category">
      <div className="section-heading">
        <div>
          <p className="eyebrow">EXPLORE</p>
          <h2>Shop by category</h2>
        </div>
        <p className="section-sub">Everything you need to bring your garden to life</p>
      </div>
      <div className="category-grid">
        {CATEGORIES.slice(0, 6).map((cat) => (
          <Link to={`/category/${cat.slug}`} key={cat.slug} className="category-tile" style={{ backgroundImage: `linear-gradient(to top, rgba(15,17,21,0.75), rgba(15,17,21,0.05)), url(${cat.image})` }}>
            <span className="category-tile-label">{cat.label}</span>
            <span className="category-tile-link">Explore →</span>
          </Link>
        ))}
      </div>
    </section>
  );
}

function CompleteGarden() {
  return (
    <section className="complete-garden">
      <div className="complete-garden-media">
        <img src="https://images.unsplash.com/photo-1518831959646-742c3a14ebf7?q=80&w=900&auto=format&fit=crop" alt="Ferns" />
      </div>
      <div className="complete-garden-copy">
        <h2>Complete your garden, not just your cart.</h2>
        <p>Pair a plant with the right pot, growing media and nutrition. Our catalogue brings the complete gardening journey together.</p>
        <div className="pill-row">
          <span className="pill">🌱 Your plant</span>
          <span className="pill-plus">+</span>
          <span className="pill">🪴 Right pot</span>
          <span className="pill-plus">+</span>
          <span className="pill">🌾 Growing mix</span>
          <span className="pill-plus">+</span>
          <span className="pill">💧 Plant nutrition</span>
        </div>
        <Link to="/category/pots-planters" className="btn-build-garden">Build your garden →</Link>
      </div>
    </section>
  );
}

function BestSellers() {
  const products = getBestSellers(8);
  return (
    <section className="best-sellers">
      <div className="section-heading">
        <div>
          <p className="eyebrow">LOVED BY OUR GARDENERS</p>
          <h2>Plants people love</h2>
        </div>
        <Link to="/category/indoor-plants" className="see-all">See all →</Link>
      </div>
      <div className="product-grid">
        {products.map((p) => (
          <ProductCard key={p.id} product={p} />
        ))}
      </div>
    </section>
  );
}

function GardenServicesTeaser() {
  const services = [
    { title: 'Terrace Garden', to: '/garden-services' },
    { title: 'Balcony Garden', to: '/garden-services' },
    { title: 'Landscaping', to: '/garden-services' },
    { title: 'Plant Maintenance', to: '/garden-services' },
  ];
  return (
    <section className="garden-services-teaser">
      <div className="section-heading">
        <div>
          <p className="eyebrow">BEYOND PRODUCTS</p>
          <h2>Garden Services</h2>
        </div>
        <p className="section-sub">From terrace gardens to full landscaping, our team can help.</p>
      </div>
      <div className="services-grid">
        {services.map((s) => (
          <Link to={s.to} key={s.title} className="service-card">
            <h3>{s.title}</h3>
            <span>Learn more →</span>
          </Link>
        ))}
      </div>
    </section>
  );
}

function WhyIGO() {
  return (
    <section className="why-igo">
      <div className="section-heading center">
        <p className="eyebrow">WHY IGO NURSERY</p>
        <h2>Grown with data, delivered with care</h2>
      </div>
      <div className="why-igo-grid">
        {WHY_IGO.map((item) => (
          <div className="why-igo-card" key={item.title}>
            <h3>{item.title}</h3>
            <p>{item.desc}</p>
          </div>
        ))}
      </div>
    </section>
  );
}

function PlantFinderBand() {
  return (
    <section className="plant-finder-band">
      <div>
        <p className="eyebrow light">PLANT FINDER</p>
        <h2>Not sure where to begin?</h2>
        <p>Start with easy-care plants, compact-space favourites or fruit and herb growers.</p>
      </div>
      <Link to="/category/indoor-plants" className="btn-find-plant">Find my plant</Link>
    </section>
  );
}

function GardenJournal() {
  return (
    <section className="garden-journal">
      <div className="section-heading">
        <div>
          <p className="eyebrow">LEARN • GROW • THRIVE</p>
          <h2>Garden journal</h2>
        </div>
        <Link to="/blog" className="see-all">See all →</Link>
      </div>
      <div className="journal-grid">
        {JOURNAL.map((post, i) => (
          <Link to={post.to} key={post.title} className="journal-card">
            <div className="journal-media" style={{ backgroundImage: `url(https://images.unsplash.com/photo-${['1416879595882-3373a0480b5b','1416339306562-c3755a8ea099','1463154545680-d59320fd685d'][i]}?q=80&w=500&auto=format&fit=crop)` }} />
            <h3>{post.title}</h3>
            <span>Read guide →</span>
          </Link>
        ))}
      </div>
    </section>
  );
}

function Reviews() {
  return (
    <section className="reviews-section">
      <div className="section-heading center">
        <h2>Customer reviews</h2>
        <p className="section-sub">4.8 / 5 average across 2,400+ orders</p>
      </div>
      <div className="reviews-grid">
        {REVIEWS.map((r) => (
          <div className="review-card" key={r.name}>
            <p className="review-stars">{'★'.repeat(r.rating)}{'☆'.repeat(5 - r.rating)}</p>
            <p className="review-text">&ldquo;{r.text}&rdquo;</p>
            <p className="review-name">{r.name}</p>
          </div>
        ))}
      </div>
    </section>
  );
}

function Faq() {
  const [open, setOpen] = useState(0);
  return (
    <section className="faq-section" id="faq">
      <div className="section-heading center">
        <p className="eyebrow">SUPPORT</p>
        <h2>We've probably answered it already</h2>
      </div>
      <div className="faq-list">
        {FAQS.map((item, idx) => (
          <div className={`faq-item ${open === idx ? 'open' : ''}`} key={item.q}>
            <button type="button" onClick={() => setOpen(open === idx ? -1 : idx)}>
              <span>{item.q}</span>
              <span className="faq-toggle">{open === idx ? '−' : '+'}</span>
            </button>
            {open === idx && <p>{item.a}</p>}
          </div>
        ))}
      </div>
    </section>
  );
}

function Newsletter() {
  return (
    <section className="newsletter-section">
      <h2>Get growing tips in your inbox.</h2>
      <form onSubmit={(e) => e.preventDefault()} className="newsletter-form">
        <input type="email" placeholder="you@example.com" required />
        <button type="submit">SUBSCRIBE</button>
      </form>
    </section>
  );
}

function Home() {
  return (
    <>
      <Hero />
      <OffersSection />
      <ShopByCategory />
      <BestSellers />
      <CompleteGarden />
      <GardenServicesTeaser />
      <WhyIGO />
      <PlantFinderBand />
      <GardenJournal />
      <Reviews />
      <Newsletter />
      <Faq />
    </>
  );
}

export default Home;
