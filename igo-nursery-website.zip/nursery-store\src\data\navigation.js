export const NAV_ITEMS = [
  {
    label: 'Plants',
    to: '/category/indoor-plants',
    children: [
      { label: 'Indoor Plants', to: '/category/indoor-plants' },
      { label: 'Outdoor Plants', to: '/category/outdoor-plants' },
      { label: 'Bonsai', to: '/category/bonsai' },
    ],
  },
  {
    label: 'Seeds',
    to: '/category/seeds',
    children: [{ label: 'All Seeds', to: '/category/seeds' }],
  },
  {
    label: 'Pots & Planters',
    to: '/category/pots-planters',
    children: [
      { label: 'All Pots & Planters', to: '/category/pots-planters' },
      { label: 'Gardening Tools', to: '/category/gardening-tools' },
      { label: 'Garden Décor', to: '/category/garden-decor' },
    ],
  },
  {
    label: 'Plant Care',
    to: '/blog',
    children: [
      { label: 'Garden Journal', to: '/blog' },
      { label: 'FAQ', to: '/#faq' },
    ],
  },
  { label: 'Gifting', to: '/gifting' },
  { label: 'Corporate Gifts', to: '/corporate-gifts' },
  { label: 'Garden Services', to: '/garden-services' },
  { label: 'Blog', to: '/blog' },
  { label: 'Offers', to: '/offers', highlight: true },
  { label: 'Locate Store', to: '/locate-store' },
];

export const FOOTER_LINKS = {
  shop: [
    { label: 'Plants', to: '/category/indoor-plants' },
    { label: 'Seeds', to: '/category/seeds' },
    { label: 'Pots & Planters', to: '/category/pots-planters' },
    { label: 'Plant Care', to: '/blog' },
    { label: 'Garden Décor', to: '/category/garden-decor' },
    { label: 'Offers', to: '/offers' },
  ],
  discover: [
    { label: 'Our Story', to: '/about' },
    { label: 'Gifting', to: '/gifting' },
    { label: 'Garden Services', to: '/garden-services' },
    { label: 'Blog', to: '/blog' },
    { label: 'FAQ', to: '/#faq' },
    { label: 'Locate Store', to: '/locate-store' },
  ],
  account: [
    { label: 'My Account', to: '/login' },
    { label: 'Orders', to: '/login' },
    { label: 'Wishlist', to: '/wishlist' },
    { label: 'Cart', to: '/cart' },
    { label: 'Contact', to: '/locate-store' },
  ],
};
