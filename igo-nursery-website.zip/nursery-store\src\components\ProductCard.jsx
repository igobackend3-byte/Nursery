import { Link } from 'react-router-dom';
import { useStore } from '../context/StoreContext';

function ProductCard({ product }) {
  const { wishlist, toggleWishlist } = useStore();
  const isWishlisted = wishlist.includes(product.id);

  return (
    <div className="product-card">
      <Link to={`/product/${product.id}`} className="product-card-media">
        <img src={product.image} alt={product.name} loading="lazy" />
        <span className="rating-badge">{product.rating}/{product.reviews}</span>
        <button
          type="button"
          className={`wishlist-btn ${isWishlisted ? 'active' : ''}`}
          onClick={(e) => {
            e.preventDefault();
            toggleWishlist(product.id);
          }}
          aria-label="Toggle wishlist"
        >
          <svg width="18" height="18" viewBox="0 0 24 24" fill={isWishlisted ? '#e63946' : 'none'} stroke={isWishlisted ? '#e63946' : '#333'} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path></svg>
        </button>
      </Link>
      <div className="product-card-body">
        <Link to={`/product/${product.id}`}>
          <h3>{product.name}</h3>
        </Link>
        <p className="product-card-category">{product.categoryLabel}</p>
        <div className="product-card-price">
          <span className="price-now">₹{product.price}</span>
          <span className="price-was">₹{product.originalPrice}</span>
        </div>
        <p className="price-off">₹{product.discount} OFF</p>
        <Link to={`/product/${product.id}`} className="btn-details">
          DETAILS
        </Link>
      </div>
    </div>
  );
}

export default ProductCard;
